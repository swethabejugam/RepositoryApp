package com.swetha.repoapp.model

data class Post(val id:Int,
                val name:String,
                val full_name:String,
                val description:String)